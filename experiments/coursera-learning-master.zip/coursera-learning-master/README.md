# coursera-learning
## Foundations of Data Science: K-Means Clustering in Python (Coursera)

Exercises and projects from the Coursera course "Foundations of Data Science: K-Means Clustering in Python" undertaken in February 2020.
